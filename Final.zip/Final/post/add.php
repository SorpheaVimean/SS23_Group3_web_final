<?php
session_start();



if(!isset($_SESSION['user'])){
    $message = "Please Login.";
    $_SESSION['message']= $message;
    header("Location: /final/login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Post</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://cdn.tiny.cloud/1/lbxfbof1ryarl81js3itcwcd29fzx0spacsxltbypf9hud9y/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
</head>

<body>
    <div class="container" >
        <div class="row justify-content-center mt-3">
            <div>
                <form method="POST" enctype="multipart/form-data" action="/Final/pdo/core/post_controller.php">
                    <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Title :</label>
                            <input type="text" class="form-control" name="title">
                    </div>
                    <div class="mb-2">
                    <label for="exampleInputPassword1" class="form-label">Thumbnail :</label>
                    <input type="file" name="thumbnail">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Content :</label>
                        <textarea rows=6 name="content">
                        </textarea>
                    </div>
                    <div>
                    <button type="submit" class="custom-btn btn-5" name="add_post">Save</button>
                    <button type="submit" class="custom-btn btn-4" name="add_cancel">Cancel</button>
                </form>
            
                <script>
                    const image_upload_handler_callback = (blobInfo, progress) => new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.withCredentials = false;
                    xhr.open('POST', '/final/image_post_upload.php');
                    
                    xhr.upload.onprogress = (e) => {
                        progress(e.loaded / e.total * 100);
                    };
                    
                    xhr.onload = () => {
                        console.log(xhr.responseText);
                        if (xhr.status === 403) {
                            reject({ message: 'HTTP Error: ' + xhr.status, remove: true });
                            return;
                        }
                    
                        if (xhr.status < 200 || xhr.status >= 300) {
                            reject('HTTP Error: ' + xhr.status);
                            return;
                        }
                    
                        const json = JSON.parse(xhr.responseText);
                    
                        if (!json || typeof json.location != 'string') {
                            reject('Invalid JSON: ' + xhr.responseText);
                            return;
                        }
                    
                        resolve(json.location);
                    };
                    
                    xhr.onerror = () => {
                    reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
                    };
                    
                    const formData = new FormData();
                    formData.append('file', blobInfo.blob(), blobInfo.filename());
                    
                    xhr.send(formData);
                    });
                </script>
                <script>
                    tinymce.init({
                        forced_root_block : 'false',
                        selector: 'textarea',
                        plugins: 'image',
                        height : "650",
                        toolbar: 'undo redo | styles | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | image',

                    //     setup: function (editor) {
                    //     editor.on('init', function () {
                    //         editor.setContent('This is the content to load into the editor');
                    //     })
                    // },
                        
                        // without images_upload_url set, Upload tab won't show up
                        images_upload_url: '/final/image_post_upload.php',
                        
                        // override default upload handler to simulate successful upload
                        images_upload_handler: image_upload_handler_callback
                    });
                </script>
            </div>
        </div>
    </div>
</body>
</html>