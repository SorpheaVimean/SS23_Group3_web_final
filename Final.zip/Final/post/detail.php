<?php

$host     = 'localhost:3308';
$db       = 'orochi_db';
$user     = 'root';
$password = 'V908080';

$dsn = "mysql:host=$host;dbname=$db;charset=UTF8";

try {
  
  $conn = new PDO($dsn, $user, $password);
  $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
  
}catch(PDOException $e) {
  echo $e->getMessage();
  die($e);
}


if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql_get_post = "SELECT * from article where id=:id";
    $handler = $conn->prepare($sql_get_post);
    $handler->bindValue(":id",$id);
    $handler->execute();
    $post = $handler->fetch();
    // print_r($post);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title><?= $post->title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<style>
    .right-column2{
        margin-left: 80px;
        margin-top: 50px;
    }
   
</style>
<body >
<!-- <div class="container"> -->
    <!-- Left Col -->
    
 
                <div class="right-column2">
                <h1>More info</h1>
                        <div>          
                          <h2  class="toppic2"><?=$post->title?></h2>
                          <p id="para"><?= $post->content ?></p>                                    
                        </div>                                                                
                </div>                                                                
        
   

     <!-- Right Col -->
        <div id="col3" class="col-2">
        <div class="sticky-top">
            <h1></h1>
            
        </div>
        </div>
    </div>
<!-- </div> -->
</body>
</html>