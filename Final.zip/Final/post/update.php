<?php
session_start();
$host     = 'localhost:3308';
$db       = 'orochi_db';
$user     = 'root';
$password = 'V908080';

$dsn = "mysql:host=$host;dbname=$db;charset=UTF8";

try {
  
  $conn = new PDO($dsn, $user, $password);
  $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
  
}catch(PDOException $e) {
  echo $e->getMessage();
  die($e);
}

if(!isset($_SESSION['user'])){
    $message = "Please Login.";
    $_SESSION['message']= $message;
    header("Location: /final/login.php");
}

if(isset($_SESSION['user'])){
    $author_id = $_SESSION['user']->id;
    if($author_id==1){
        $sql_get_post = "SELECT * from article";
        $handler = $conn->prepare($sql_get_post);
        $handler->execute();
        $post_list= $handler->fetchAll(PDO::FETCH_ASSOC);
    }else{
        $sql_get_post = "SELECT * from article where author=:author";
        $handler = $conn->prepare($sql_get_post);
        $handler->bindValue(":author",$author_id);
        $handler->execute();
        $post_list = $handler->fetchAll(PDO::FETCH_ASSOC);
        // print_r($post);
    }
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql_get_post_detail = "SELECT * from article where id=:id";
    $handler = $conn->prepare($sql_get_post_detail);
    $handler->bindValue(":id",$id);
    $handler->execute();
    $post_detail = $handler->fetch();
    // print_r($post);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Update Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://cdn.tiny.cloud/1/lbxfbof1ryarl81js3itcwcd29fzx0spacsxltbypf9hud9y/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        *{
            /* background-color:black; */
        }
    </style>
</head>
<body >
  
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-3" style="color: black; border-color: #44474e; border-style: solid; border-width: 2px; border-radius: 20px; ">
                <h5 style="text-align:center;">Your Posts: </h5>
                <ul style="list-style-type: none; margin-right: 25px">
                <?php foreach($post_list as $update_post) : ?>
                    <li><a id="list" href="update.php?id=<?= $update_post['id']; ?>" style="text-decoration: none; color:black;"><?= $update_post['title'] ?></a></li>
                <?php endforeach ?>
                </ul>
            </div>
            <div class="col-8"  style="color: black; border-color: #44474e; border-style: solid; border-width: 2px; border-radius: 20px;">
                <form method="POST" enctype="multipart/form-data" action="/Final/pdo/core/post_controller.php">
                    <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Title :</label>
                            <input type="text" class="form-control" value="<?php if(isset($_GET['id'])) : ?><?= $post_detail->title?><?php endif; ?>
                            " name="title">
                    </div>
                    <div class="mb-2">
                    <label for="exampleInputPassword1" class="form-label">Thumbnail :</label>
                    <input type="file" name="thumbnail">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Content :</label>
                        <textarea rows=6 name="content">
                        </textarea>
                    </div>
                    <div class="row">
                    <div class="col-2">
                        <button type="submit" class="custom-btn btn-5" name="update_post">Update</button>
                    </div>
                    <div class="col-7">
                        <button type="submit" class="custom-btn btn-4" name="update_cancel">Cancel</button>
                    </div>
                    <div class="col-3">
                        <input type="hidden" value="<?php if(isset($_GET['id'])) : ?><?= $post_detail->id ?><?php endif; ?>" name="update_delete_id" >
                    <button type="submit" class="custom-btn btn-3" name="delete_post">Delete</button>
                    </div>
                    </div>
                </form>
                <script>
                    const image_upload_handler_callback = (blobInfo, progress) => new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.withCredentials = false;
                    xhr.open('POST', '/Final/image_post_upload.php');
                    
                    xhr.upload.onprogress = (e) => {
                        progress(e.loaded / e.total * 100);
                    };
                    
                    xhr.onload = () => {
                        console.log(xhr.responseText);
                        if (xhr.status === 403) {
                            reject({ message: 'HTTP Error: ' + xhr.status, remove: true });
                            return;
                        }
                    
                        if (xhr.status < 200 || xhr.status >= 300) {
                            reject('HTTP Error: ' + xhr.status);
                            return;
                        }
                    
                        const json = JSON.parse(xhr.responseText);
                    
                        if (!json || typeof json.location != 'string') {
                            reject('Invalid JSON: ' + xhr.responseText);
                            return;
                        }
                    
                        resolve(json.location);
                    };
                    
                    xhr.onerror = () => {
                    reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
                    };
                    
                    const formData = new FormData();
                    formData.append('file', blobInfo.blob(), blobInfo.filename());
                    
                    xhr.send(formData);
                    });
                </script>
                <script>
                    tinymce.init({
                        forced_root_block : 'false',
                        selector: 'textarea',
                        plugins: 'image',
                        height : "650",
                        toolbar: 'undo redo | styles | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | image',

                        setup: function (editor) {
                        <?php if(isset($_GET['id'])) : ?>
                        editor.on('init', function () {
                            editor.setContent('<?= $post_detail->content?>');
                        })
                        <?php endif; ?>
                    },
                        
                        // without images_upload_url set, Upload tab won't show up
                        images_upload_url: '/Final/image_post_upload.php',
                        
                        // override default upload handler to simulate successful upload
                        images_upload_handler: image_upload_handler_callback
                    });
                </script>
            </div>
        </div>
    </div>
</body>
</html>