<?php

session_start();
// include ("header.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  <title>Login</title>
  <style>
      .container{
        margin-top: 50px;
      }
    </style>
</head>
<body>
  <div class="container">
    <h1>Login Form</h1>
    <div class="text-center">
      <?php if(isset($_SESSION['message'])) : ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <?= $_SESSION['message']; ?>
          <?php unset($_SESSION['message']); ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>
    </div>
    <Form method="POST" action="pdo/core/auth.php">
    <div class="mb-3 row">
      <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" name="email" placeholder="email">
        </div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" placeholder="password">
    </div>
  </div>

  <div class="form-check">
  <input class="form-check-input" type="checkbox" id="flexCheckDefault" name="remember">
  <label class="form-check-label" for="flexCheckDefault">
    Remember
  </label>
</div>

      <div class ="row">
          <div class ="col-6">
            <button type="submit" class ="btn btn-primary" name="login">Submit</button>
            <div class="register-link">
                <p>Don't have an account?<a href="register.php" class="link-register">Register </a></p>
            </div>
          </div>
      </div>

    </Form>

  </div>
</body>
</html>