<?php

session_start();
// include ("header.php");
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ"
      crossorigin="anonymous"/>
    
    <title>Register</title>
    <style>
      .container{
        margin-top: 50px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <form method="POST" action="/final/pdo/core/auth.php">
        <div class="row justify-content-center">
          <h2>Create Account</h2>
          <div class="col-6">
          <?php if(isset($_SESSION['message'])) : ?>
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                         <?= $_SESSION['message']; ?>
                          <?php unset($_SESSION['message']); ?>
                           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                     </div>
                <?php endif;?> 
            <div class="mb-3">
              <label for="email" class="form-label">Email : </label>
              <input type="email" class="form-control" id="email" name= "email" placeholder="name@example.com"/>
            </div>

            <div class="mb-3">
              <label for="username" class="form-label">Username : </label>
              <input type="username" class="form-control" id="username" name= "username" placeholder="username"/>
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Password : </label>
              <input type="password" class="form-control" id="password" name= "password" placeholder="password"/>
            </div>

            <div class="mb-3">
              <label for="re-password" class="form-label">Re-password : </label>
              <input type="password" class="form-control" id="re-password" name= "re-password" placeholder="re-password"/>
            </div>

            <div class="mb-3">
              <button type="submit" class="btn btn-primary" name="create-account">Create Account</button>
              <div class="login-link">
            <p>Already have an account?<a href="login.php" class="link-login">Sign in</a></p>
            </div>
            </div>
            </div>    

          </div>
        </div>
      </form>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe">
      crossorigin="anonymous"
    </script>
  </body>
</html>
