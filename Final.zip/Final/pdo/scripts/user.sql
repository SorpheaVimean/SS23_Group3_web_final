create table user(
  id int AUTO_INCREMENT PRIMARY KEY,
  name varchar(255) NOT NULL,
  email varchar(255) NOT NULL UNIQUE,
  pass varchar(500),
  create_at datetime default CURRENT_TIMESTAMP,
  token varchar(6),
  expire_token_at datetime NOT NULL,
  status tinyint default 0,
  is_admin tinyint default 0

)
