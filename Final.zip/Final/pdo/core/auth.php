<?php
session_start();
require("database.php");
require("functional.php");
require("send_mail.php");
//register
if(isset($_POST['create-account'])){
  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $repassword = $_POST['re-password'];
  //validation

  //if validation pass
  $query_add_user = "INSERT INTO user (email, username, pass, token, expire_token_at)
                      VALUES (:email, :username, :pass, :token, :expire_token_at)";
  $token = generate_token();
  $token_exp = generate_token_expire_at(150);
  $handler = $conn->prepare($query_add_user);
  $handler->bindValue("email", $email);
  $handler->bindValue("username", $username);
  $handler->bindValue("pass", md5($password));
  $handler->bindValue("token", $token);
  $handler->bindValue("expire_token_at", $token_exp);
  if($handler ->execute()){
    //redirect to verify page
    $message= "Your token is :" . $token . " .";
    $is_sent = send_mail($email, $username, "Verify email address", $message,);
    // $is_sent =true;
    if($is_sent){
      //redirect to verify page
      $_SESSION['message']=$message;
      $_SESSION['email']=$email;


      // $_SESSION['user']= array(
      //   [name] => $username,
      //   [email] => $email 
      // );
      header("Location: /Final/verify_email.php");


    }else{
      $message = "Please check your mailbox go to get token code.";
      $_SESSION['message'] = $message;
      header("Location: /Final/verify_email.php");
    }
  }else{
    //redirect back to register page with error message

    $message = "Something wrong";
    $_SESSION['message'] = $message;
    header("Location: register.php");
  }

} 
//register token
if(isset($_POST['token']) && isset($_POST['email'])){
  $query_get_user = "SELECT * FROM user WHERE email = :email and token=:token";
  $handler = $conn->prepare($query_get_user);
  $handler->bindValue("email", $_POST['email']);
  $handler->bindValue("token", $_POST['token']);

  $handler ->execute();

  $user= $handler ->fetch();
  echo $user->expire_token_at;
  $current_time =time();

  if($current_time < $user->expire_token_at){
    $query_update_status = "UPDATE user SET status=1 WHERE email = :email and token=:token";
    $handler = $conn->prepare($query_update_status);
    $handler->bindValue("email", $_POST['email']);
    $handler->bindValue("token", $_POST['token']);

    if($handler ->execute() ){
      header("Location: /Final/login.php");
    }
  }
}

//login

if(isset($_POST['login'])){
  $email = $_POST['email'];
  $password = $_POST['password'];

  $sql_login="SELECT id,username,email,is_admin FROM user WHERE email=:email AND pass=:pass AND status=1";

  $handler = $conn->prepare($sql_login);
  $handler->bindValue("email", $email);
  $handler->bindValue("pass", md5($password));

  $handler ->execute();
  $user = $handler->fetch();
  if($user){
    $_SESSION['user'] = $user;
    header("Location: /Final/index.php");

  }else{
    $_SESSION['message'] = "Invalid email or password";
    header("Location: /Final/login.php");
  }
  // var_dump($user->username);
}

//logout

if(isset($_POST['logout'])){
  session_destroy();
  header("Location: /Final/login.php");
}