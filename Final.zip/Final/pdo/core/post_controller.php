<?php
session_start();
require("database.php");
// echo "Hello World";
if($conn){
    echo "successful";
}

if(!isset($_SESSION['user'])){
    $message = "Please Login.";
    $_SESSION['message']= $message;
    header("Location: /final/login.php");
}

if(isset($_POST['add_post'])){
    $title= $_POST['title'];
    $content = $_POST['content'];
    $author = $_SESSION['user']->id;

    // echo dirname(__FILE__ );
    $filename = "C:\wamp\www\Final\post_images/" . 
    $_FILES['thumbnail']["name"];
    move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $filename);

    echo $_FILES['thumbnail']["name"];
    echo $title;
    echo $content;

    $query_add_article = "INSERT into article (title,content,author,thumbnail) values(:title,:content,:author,:thumbnail)";
    $handler = $conn->prepare($query_add_article);
    $handler->bindValue(":title",$title);
    $handler->bindValue(":content",$content);
    $handler->bindValue(":author",$author);
    $handler->bindValue(":thumbnail",$_FILES['thumbnail']["name"]);
    // $handler->bindValue(":thumbnail",$thumbnail);

    if($handler->execute()){
        header("Location: /Final/index.php");
    }
}


//Udated content
if(isset($_POST['update_post'])){
    $title= $_POST['title'];
    $content = $_POST['content'];
    $update_id = $_POST['update_delete_id'];

    echo $title;
    echo $content;
    echo $update_id;

    $filename = "C:\wamp\www\Final\post_images/" . 
    $_FILES['thumbnail']["name"];
    move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $filename);

    echo $_FILES['thumbnail']["name"];

    if($_FILES['thumbnail']["name"]){
        $filename = "C:\wamp\www\Final\post_images/" . 
        $_FILES['thumbnail']["name"];
        move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $filename);

        $query_update_article_wt = "update article set title=:title, content=:content, thumbnail=:thumbnail where id=:id";
        $handler = $conn->prepare($query_update_article_wt);
        $handler->bindValue(":title",$title);
        $handler->bindValue(":content",$content);
        $handler->bindValue(":thumbnail",$_FILES['thumbnail']["name"]);
        $handler->bindValue(":id",$update_id);
        
        if($handler->execute()){
            header("Location: /Final/index.php");
        }
    }else{
        $query_update_article_wot = "update article set title=:title, content=:content where id=:id";
        $handler = $conn->prepare($query_update_article_wot);
        $handler->bindValue(":title",$title);
        $handler->bindValue(":content",$content);
        $handler->bindValue(":id",$update_id);
        
        if($handler->execute()){
            header("Location: /Final/index.php");
        }
    }
}



if(isset($_POST['delete_post'])){
    $delete_id = $_POST['update_delete_id'];

    $query_delete_post = "Delete From article where id=:id" ;
    $handler = $conn->prepare($query_delete_post);
    $handler->bindValue(":id",$delete_id);
    if($handler->execute()){
        header("Location: /Final/index.php");
    }

}


if(isset($_POST['update_cancel'])){
    unset($_POST['update_cancel']);
    header("Location: /Final/index.php");
}
if(isset($_POST['add_cancel'])){
    unset($_POST['add_cancel']);
    header("Location: /Final/index.php");
}
?>