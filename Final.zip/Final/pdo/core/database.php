<?php

$host     = 'localhost:3308';
$db       = 'orochi_db';
$user     = 'root';
$password = 'V908080';

$dsn = "mysql:host=$host;dbname=$db;charset=UTF8";

try {
  
  $conn = new PDO($dsn, $user, $password);
  $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
  
}catch(PDOException $e) {
  echo $e->getMessage();
  die($e);
}