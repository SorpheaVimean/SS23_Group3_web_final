<?php
function generate_token(){
  $num = rand(0,999999);
  return sprintf("%06d", $num);

}

function generate_token_expire_at($minute){
  $current_time = time();
  $exp = $current_time + 60*$minute;
  return $exp; 
}

// echo generate_token_expire_at();

?>