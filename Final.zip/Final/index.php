<?php

session_start();
require("pdo/core/database.php");
include ("header.php");

if(!isset($_SESSION['user'])){
  $_SESSION['message'] = "Please login first.";
  header("Location: /final/login.php");
}

$sql_get_post = "SELECT * from article";
$handler = $conn->query($sql_get_post);
if($handler){
    $result_all = $handler->fetchAll(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App</title>
  <style>
    .myDiv{
      width: 300px;
      height:250px;
      margin-top: 100px;
    }
    .divNormal {
      
    }
    .feature2{
      /* display:flex;
      flex-direction: block;
      align-items: center;
      background-color: red; */

      display:flex;
  margin: 80px;
  border-radius: 15px;
  height: auto;
  margin-top: 25px;
  margin-bottom: 35px;
  border-color: #44474e;
  border-style: solid;
  border-width: 2px;
  overflow: hidden;

    }
    /* .left-column1{
      width: 200px;
      background-color: blue;
    } */
    .left-column1{
    /* background-color:green; */
     width: auto;
    overflow: hidden;
    }
    .left-column1 img{
      object-fit: contain;
      /* background-color: blue; */
      width:100px;
      scale:1.5;
      transition: 018s ease;
    }
    .left-column1 img:hover{
      scale: 1.5;
    }
    .right-column2{
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .recent{
      margin-top: 100px;
      display:flex;
  margin: 80px;
  font-size: 80px;
    }
  </style>
</head>
<body>
  
  <?= "Welcome" . " " . $_SESSION['user']->username; ?>
  <form method="POST" action="pdo/core/auth.php">
  </form>
    <?php if($_SESSION['user'] ->is_admin) : ?>
  <div class="myDiv">
      For Admin Only
  </div>
    <?php endif; ?>
 


  <h5 class="recent"> Recent Article</h5>
                <?php foreach($result_all as $post) : ?>
                <div class="feature2">
                    <div class="left-column1">
                        <a href="post/detail.php?id=<?= $post['id']; ?>"><img class="profile2" src="post_images/<?= $post['thumbnail'] ?>" style="margin-top: 15px;"></a>
                    </div>


                <div class="right-column2">
                        <div>          
                          <a href="post/detail.php?id=<?= $post['id']; ?>"><h2  class="toppic2"><?= $post['title'] ?> </h2></a>                   
                        </div>                                                                
                </div>
                </div>
                <?php endforeach; ?>      


</body>
</html>